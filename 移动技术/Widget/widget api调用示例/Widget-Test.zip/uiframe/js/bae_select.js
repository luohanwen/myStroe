;
$(function () {
    $.extend({getAttrFixed: function (e, key) {
        var value = e.getAttribute(key);
        return value === "true" ? true : value === "false" ? false : value === null ? undefined : value
    }});

    $.fn.bae_select = function (options) {
        var $jqObj = this;
        this.refresh = function () {
            $.each($jqObj, function (index, ele) {
                var $eleSelect = $(ele);
                if (!$eleSelect.attr("data-init")) {
                    return true
                }
                var $eleParent = $eleSelect.parent();
                var $eleText = $eleParent.find('span .ui-bae-btn-text');
                if ($eleText.length > 0) {
                    $eleText.text($eleSelect.children('option:selected').text())
                }
            })
        };
        options = (options && ($.type(options) === "object")) ? options : {};
        $.each($jqObj, function (index, ele) {
            var $eleSelect = $(ele);
            var eleSelect = ele;
	        //update style by params
            if ($eleSelect.attr("data-init")) {
                if (typeof options.inline == "boolean") {
                    $eleSelect.bae_select_setInline(options.inline)
                }
                if (typeof options.disable == "boolean") {
                    $eleSelect.bae_select_setDisable(options.disable)
                }
                if (typeof options.width == "string" || typeof options.width == "number") {
                    $eleSelect.bae_select_setWidth($.fn.bae_select_parsePixelValue(options.width))
                }
                if (typeof options.height == "string" || typeof options.height == "number") {
                    $eleSelect.bae_select_setHeight($.fn.bae_select_parsePixelValue(options.height))
                }
                return true
            }
	        //create bae_select style
            var width = 0;
            var height = 0;
            if ($eleSelect.is(":visible") == true) {
                    width = $eleSelect.outerWidth();
                    height = $eleSelect.outerHeight();
            }
            var o = $.extend({}, $.fn.bae_select.defaults, {
	    	    inline: options.inline !== undefined ? options.inline : $.getAttrFixed(eleSelect, "data-inline"),
		        width: options.width !== undefined ? options.width : width,
		        height: options.height !== undefined ? options.height : height,
		        disable: options.disable !== undefined ? options.disable : false
	        }, options);

            var inlineStyle = o.inline ? "ui-bae-select-inline" : "";
            var widthStyle = "";
            var heightStyle = "";
            var disableBtnStyle = "";
            var disableIconStyle = "";
            if (o.width > 0) {
                widthStyle = "width:" + o.width + "px;"
            }
            if (o.height > 0) {
                heightStyle = "height:" + o.height + "px;line-height:" + o.height + "px;"
            }
            if (true == o.disable) {
                disableBtnStyle = " ui-bae-select-disable";
                disableIconStyle = " ui-bae-select-icon-disable";
                $eleSelect.hide()
            } else {
                disableBtnStyle = " ui-bae-select-enable";
                disableIconStyle = " ui-bae-select-icon-enable"
            }
            var NewLine = '\n';
            var nodeEle = document.createElement("div");
            ele.parentNode.insertBefore(nodeEle, ele);
            nodeEle.className = o.inline ? "ui-bae-select-inline" : "";
            if(o.width>0){
                nodeEle.style.width = o.width + "px";
            }
            var decoratedHtml = '';
            decoratedHtml += '<div class="ui-bae-select ui-bae-btn-icon-right ui-bae-select-corner-all ui-bae-shadow ' + disableBtnStyle + '">' + NewLine;
            decoratedHtml += '<span name="select-btn" class="ui-bae-btn-inner" aria-hidden="true">' + NewLine;
            decoratedHtml += "<span class='ui-bae-btn-text' style='" + heightStyle + "'>" + $eleSelect.children('option:selected').text() + '</span>' + NewLine;
            decoratedHtml += '<span class="ui-bae-select-icon ' + disableIconStyle + '"></span>' + NewLine;
            decoratedHtml += '</span>' + NewLine;
            decoratedHtml += '</div>' + NewLine;
            nodeEle.innerHTML = decoratedHtml;
            nodeEle.firstChild.insertBefore(ele, null);
            ele.setAttribute("onchange", "javascript:this.parentElement.firstElementChild.firstElementChild.innerHTML = this.options[this.selectedIndex].text;" + ele.getAttribute("onchange"));
            ele.setAttribute("data-init", 'true');
            var $newSelectDiv = $(nodeEle).find('.ui-bae-select');
            $newSelectDiv.get(0).addEventListener("touchstart", function (ev) {
                $newSelectDiv.addClass("active")
            }, false);
            $newSelectDiv.get(0).addEventListener("touchmove", function (ev) {
                ev.preventDefault()
            }, false);
            $newSelectDiv.get(0).addEventListener("touchend", function (ev) {
                setTimeout(function () {
                    $newSelectDiv.removeClass("active")
                }, 300)
            }, false)
        });
        return this
    };
    $.fn.bae_select.defaults = {inline: false, width: -1, height: -1, disable: false};
    $.fn.bae_select_parsePixelValue = function (p) {
        if (String(p).indexOf("px") > -1) {
            var val = parseInt(String(p).substring(0, p.length - 2));
            if (val > 0) {
                return val
            }
        } else {
            var val = parseInt(String(p));
            if (typeof val == "number") {
                return val
            }
        }
        return 0
    };
    $.fn.bae_select_setInline = function (state) {
        var $eleParent = this.parent().parent();
        if ($eleParent.is("div")) {
            state == true ? $eleParent.addClass("ui-bae-select-inline") : $eleParent.removeClass("ui-bae-select-inline")
        } else {
        }
    };
    $.fn.bae_select_setDisable = function (state) {
        typeof(state) == "boolean" ? state : state = false;
        var $eleParent = this.parent();
        var $eleIcon = $eleParent.find('span .ui-bae-select-icon');
        if (!state) {
            if ($eleParent.hasClass("ui-bae-select-disable")) {
                $eleParent.removeClass("ui-bae-select-disable");
                $eleParent.addClass("ui-bae-select-enable");
                $eleIcon.removeClass("ui-bae-select-icon-disable");
                $eleIcon.addClass("ui-bae-select-icon-enable");
                this.show()
            }
        } else {
            if ($eleParent.hasClass("ui-bae-select-enable")) {
                $eleParent.removeClass("ui-bae-select-enable");
                $eleParent.addClass("ui-bae-select-disable");
                $eleIcon.removeClass("ui-bae-select-icon-enable");
                $eleIcon.addClass("ui-bae-select-icon-disable");
                this.hide()
            }
        }
    };
    $.fn.bae_select_setWidth = function (width) {
        if (typeof width == "number" && width > 0) {
            var $eleParent = this.parent().parent();
            if ($eleParent.is("div")) {
                $eleParent.css("width", width)
            } else {
            }
        }
    };
    $.fn.bae_select_setHeight = function (height) {
        if (typeof height == "number" && height > 0) {
            var $eleParent = this.parent();
            var $eleText = $eleParent.find('span .ui-bae-btn-text');
            if ($eleText.length > 0) {
                $eleText.css("height", height + "px");
                $eleText.css("line-height", height + "px")
            } else {
            }
        }
    }
});
$(function () {
    //将所有含有“data-role='bae_select'”属性的element，修改为bae_select样式的按钮
    $("[data-role='bae_select']").bae_select()
});
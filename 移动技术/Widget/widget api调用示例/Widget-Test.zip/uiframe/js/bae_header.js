;
$(function () {
    var baeHeader = $("[data-role='bae_header']");
    $.each(baeHeader, function (index, element) {
        var jqEle = $(element);
        jqEle.addClass("ui-bae-header");
        var newChild = $(' <div class="ui-bae-header-list"><div class="ui-bae-header-left"><a href="javascript:;" data-role="bae_header_button" class="ui-bae-go-back" onclick="' + jqEle.attr("data-event") + '"></a></div> </div><ul class="ui-bae-color-line"> <li>&nbsp;</li>  <li>&nbsp;</li> <li>&nbsp;</li> <li>&nbsp;</li> <li>&nbsp;</li> </ul>');
        newChild.find(".ui-bae-header-left").after(jqEle.html());
        jqEle.empty();
        jqEle.append(newChild);
        var el = jqEle.find("[data-role='bae_header_button']");
        var e = el.get(0);
        e.addEventListener("touchstart", function (ev) {
            el.addClass("active")
        }, false);
        e.addEventListener("touchmove", function (ev) {
            ev.preventDefault()
        }, false);
        e.addEventListener("touchend", function (ev) {
            setTimeout(function () {
                el.removeClass("active")
            }, 300)
        }, false)
    })
});
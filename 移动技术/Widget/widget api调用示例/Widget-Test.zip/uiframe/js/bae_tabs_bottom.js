﻿$.fn.bae_tabs_bottom = function (options) {
    var $jqObj = this;
    options=(options&&(typeof options==="object")?options:{});
    $.each($jqObj, function (index, element) {
        var selectedTabs = $(element);
        if(selectedTabs.attr("data-init"))//判断是此tab标签是否初始化过
        {
            if(typeof options.selected==="number"||typeof options.selected==="string")
            {
                selectedTabs.bae_tabs_bottom_setSelected(parseInt(String(options.selected)));//改变指定标签的选中状态
            }
            return;
        }
        selectedTabs.addClass("ui-bae-tabs-bottom");
        var tabs = selectedTabs.find("[data-role='bae_tab']");
        var tabButtons = $('<div class="ui-bae-tab-buttons"></div>');
        var tabWidth = 100.0 / tabs.length;
        var selectedButton;
        $.each(tabs, function (index, element) {
            var tabContent = $(element);
            tabContent.addClass("unselected");
            var tabButtonName = tabContent.attr("data-tab-name");
            var tabButtonIcon = tabContent.attr("data-tab-icon");
            var tabButtonIconSelected = tabContent.attr("data-tab-icon-selected");
            if (!tabButtonIcon) {
                tabButtonIcon = "images/bae_tab_icon.png"
            }
            if (!tabButtonIconSelected) {
                tabButtonIconSelected = "images/bae_tab_icon_selected.png"
            }
            var tabButton = $('<a href="javascript:;" style="width:' + tabWidth + '%"><img data-src = "' + tabButtonIconSelected + '" src="' + tabButtonIcon + '"><br><span>' + tabButtonName + '</span></a>');
            tabButton.click(function () {
                var $img = $(this).find("img");
                var tempSrc = $img.attr("src");
                $img.attr("src", $img.attr("data-src"));
                $img.attr("data-src", tempSrc);
                $img = tabButtons.find(".current").find("img");
                tempSrc = $img.attr("src");
                $img.attr("src", $img.attr("data-src"));
                $img.attr("data-src", tempSrc);
                $(this).addClass("current").siblings().removeClass("current");
                var tabIndex = $(this).index();
                var tempTabs = selectedTabs.find("[data-role='bae_tab']");
                $(tempTabs[tabIndex]).addClass("selected").removeClass("unselected").siblings(".selected").removeClass("selected").addClass("unselected");
                var tabChangeFuncName = tabContent.attr("data-event");
				if(')'==tabChangeFuncName.charAt(tabChangeFuncName.length-1) || ';'==tabChangeFuncName.charAt(tabChangeFuncName.length-1)){
                    try {
						eval(tabChangeFuncName);
					}
					catch (e) {
					}
                }
				else {
					try {
						eval(tabChangeFuncName + "(" + tabIndex + ")");
					}
					catch (e) {
					}
				}
            });
            tabButtons.append(tabButton);
            if (tabContent.attr("data-tab-selected") === "true") {
                selectedButton = tabButton;
                tabContent.removeClass("unselected");
                tabContent.addClass("selected");
                var $img = tabButton.find("img");
                $img.attr("src", tabButtonIconSelected);
                $img.attr("data-src", tabButtonIcon)
            }
        });
        var contents = $(selectedTabs.html());
        selectedTabs.empty();
        selectedTabs.append($(tabButtons));
        selectedTabs.append(contents);
        if (typeof(selectedButton) == "object")selectedButton.addClass("current").siblings().removeClass("current")
        selectedTabs.attr("data-init",true);
    })
};
$.fn.bae_tabs_bottom_setSelected=function(tabIndex){
    var Ele=this;
    var aEle=Ele.get(0).children[0];//获得对应的a标签
    var aEleCurrent=$(aEle.children[tabIndex]);//获得当前选中a的标签
    if(tabIndex>=aEle.length) //参数的值大于等于标签的个数，不执行操作
    {
        return;
    }
    var tabs=Ele.find("[data-role='bae_tab']");// 获得所有的tabs

    var $img =  aEleCurrent.find("img");
    var tempSrc = $img.attr("src");
    $img.attr("src", $img.attr("data-src"));
    $img.attr("data-src", tempSrc);
    $img = $(aEle).find(".current").find("img");
    tempSrc = $img.attr("src");
    $img.attr("src", $img.attr("data-src"));
    $img.attr("data-src", tempSrc);
    aEleCurrent.addClass("current").siblings().removeClass("current");
    $(tabs[tabIndex]).addClass("selected").removeClass("unselected").siblings(".selected").removeClass("selected").addClass("unselected");
}
$(function () {
    //将所有含有“data-role='bae_tabs_bottom'”属性的element，修改为bae_tabs_bottom样式的按钮
    $("[data-role='bae_tabs_bottom']").bae_tabs_bottom()
});
;
$(function () {
    $.fn.bae_radio = function (options) {
        var $jqObj = this;

        options = (options && ($.type(options) === "object")) ? options : {};
        $.each($jqObj, function (index, ele) {
            var $radio = $(ele);
	        //update style by params
            if ($radio.attr("data-init")) {
                if (typeof options.disable == "boolean") {
                    $radio.bae_radio_setDisable(options.disable)
                }
                return true
            }
	        //create bae radio style
            if ($radio.attr("type") != "radio") {
                return true
            }
            var o = $.extend({}, $.fn.bae_radio.defaults, {
	    	    disable:options.disable !== undefined ? options.disable : ("disabled" == $radio.attr("disabled") ? true : false)
	        }, options);

	        //flag for accomplishment of init.
            $radio.attr("data-init", true);
            var $label = $("<label onclick='this.previousSibling.click()'></label>");
            $label.insertAfter($radio);
            var style = o.disable ? "ui-bae-radio ui-bae-radio-disable" : "ui-bae-radio ui-bae-radio-enable";
            o.disable ? $radio.attr("disabled", "") : $radio.removeAttr("disabled");
            $radio.addClass(style);
            $label.addClass(style);
            $label.bind("click", function () {
                $radio.get(0).click()
            })
        })
    };

    $.fn.bae_radio.defaults = {disable:false};

    $.fn.bae_radio_setDisable = function (state) {
        typeof(state) == "boolean" ? state : state = false;
        var $radio = this;
        var $label = this.next();
        if ($radio.is('input')) {
            if (state) {
                if (!$radio.hasClass("ui-bae-radio-disable")) {
                    $radio.removeClass("ui-bae-radio-enable");
                    $radio.addClass("ui-bae-radio-disable");
                    $radio.attr("disabled", "")
                }
            } else {
                if (!$radio.hasClass("ui-bae-radio-enable")) {
                    $radio.removeClass("ui-bae-radio-disable");
                    $radio.addClass("ui-bae-radio-enable");
                    $radio.removeAttr("disabled")
                }
            }
        }
        if ($label.is('label')) {
            if (state) {
                if (!$label.hasClass("ui-bae-radio-disable")) {
                    $label.removeClass("ui-bae-radio-enable");
                    $label.addClass("ui-bae-radio-disable")
                }
            } else {
                if (!$label.hasClass("ui-bae-radio-enable")) {
                    $label.removeClass("ui-bae-radio-disable");
                    $label.addClass("ui-bae-radio-enable")
                }
            }
        }
    }
});
$(function () {
    //将所有含有“data-role='bae_radio'”属性的element，修改为bae_radio样式的按钮
    $("[data-role='bae_radio']").bae_radio()
});
;
(
    function ($)
    {
        $.extend({bae_toast : function (message , delay)
        {
            message = message ? message : "";
            if(message == ''){
                return;
            }
            delay = delay ? delay : 1500;
            var plugin = this;
            plugin.prototype.toastTimer = null;
            if (plugin.toastTimer != null)
            {
                clearTimeout(plugin.toastTimer)
            }
            var dialog = document.getElementById('bae_toast_box');
            if (!dialog)
            {
                dialog = document.createElement("div");
                dialog.setAttribute("id" , "bae_toast_box");
            }

            dialog.style.cssText = "display:block;max-width:80%;margin-left: auto;margin-right: auto;left:-9999px;text-align:center;z-index:1002";
            dialog.innerHTML = "<span style='display: inline-block;padding: 0.4em 0.4em 0.4em 0.4em;color: #FFF;text-align: center;font-size: 22px;font-weight: 600;word-wrap: break-word;border: 1px solid #888;-webkit-border-radius: 3px;-moz-border-radius: 3px;border-radius: 3px;-moz-box-shadow: 0 1px 4px rgba(0, 0, 0, .4);-webkit-box-shadow: 0 1px 4px rgba(0, 0, 0, .4),box-shadow: 0 1px 4px rgba(0, 0, 0, .4);background: rgba(0, 0, 0, .8);-webkit-user-select:none;-ms-user-select:none;-moz-user-select:none;'>" + message + "</span>";
            document.body.appendChild(dialog);

            var zoom = $("body").css("zoom");
            if (!zoom)
            {
                zoom = 1
            }
            dialog.style.marginLeft = (
                document.body.clientWidth - dialog.offsetWidth * zoom
                ) / (
                2 * zoom
                ) + "px";
            var allHeight = document.body.scrollHeight;
            var screenHeight = document.documentElement.clientHeight;
            var scrollTop = 0;
            if(document.documentElement && document.documentElement.scrollTop){ // IE 6 Strict
                scrollTop = document.documentElement.scrollTop;
            } else if(document.body) {    // others
                scrollTop = document.body.scrollTop;
            }
            var dialogTop = -(allHeight - scrollTop - screenHeight) - dialog.clientHeight;
            dialog.style.marginTop = dialogTop + "px";
            console.log(dialogTop);

            dialog.style.display = "block";
            plugin.toastTimer = setTimeout(function ()
            {
                dialog.style.display = "none";
            } , delay);
            return this
        }})
    }
    )(jQuery);
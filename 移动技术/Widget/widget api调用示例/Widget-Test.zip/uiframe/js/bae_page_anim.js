$.bae_page_anim = function (startPage) {
    var preOperate = document.createElement("div");
    document.body.appendChild(preOperate);
    preOperate.style.display = "none";
    preOperate.style.position = "absolute";
    preOperate.style.top = "0";
    preOperate.style.right = "0";
    preOperate.style.left = "0";
    preOperate.style.bottom = "0";
    preOperate.style.zIndex = "9999";
    preOperate.onclick=function(){
        console.log('page locked when slide anim')
        event.stopPropagation();
    };

    var curPageIndex = 0;
    var pageHistory = [];

    var setStartPage =  function(startPage){
        if(startPage){
            curPageIndex = 0;
            for(var i=0;i<pageHistory.length;i++)
            {
                $("#"+pageHistory[i]).removeClass("page");
                $("#"+pageHistory[i]).removeClass("current");
            }
            pageHistory = [];
            pageHistory.push(startPage);
            var $startPage = $("#"+startPage);
            if($startPage.length != 0){
                $startPage.addClass("page")
                $startPage.addClass("current")
            }
        }else{
            console.log("can't find startpage id in bae_page_anim");
        }
    };
    setStartPage(startPage);
    /**
     *
     * @param pageTo
     * @param direction
     * @param callback
     * @param userOperate 是否为用户主动操作
     */
    var slideToPageInner = function(pageTo, direction, callback, userOperate) {
        var animation;
        var from = $("#" + pageHistory[curPageIndex]), to = $("#" + pageTo);

        if (direction == 'left') {
            animation = "slideLeft";

            curPageIndex++;

            var length = pageHistory.length;
            //如果是用户操作 则将当前页之后的历史记录清空
            if(userOperate != 'false' && curPageIndex < length){
                pageHistory = pageHistory.slice(0,curPageIndex);
            }

            //上面可能改变了数组长度 重新取值
            length = pageHistory.length;
            if (curPageIndex == length || (curPageIndex < length &&  pageTo != pageHistory[curPageIndex])) {
                //保存历史
                pageHistory.push(pageTo);
            }
        } else {
            animation = "slideRight";
            curPageIndex--;

        }

        //增加屏蔽层 禁止用户点击操作
        preOperate.style.display = "block";

        from.addClass(animation + " page out");
        to.addClass(animation + " page in current");
        to.bind("webkitAnimationEnd", function () {
            from.removeClass("current " + animation + " out");
            to.unbind("webkitAnimationEnd");
            to.removeClass(animation + " in");
            preOperate.style.display = "none";
            if (typeof callback == "function") {
                callback();
            }
        });
    };

    var back = function(callback) {
        if (pageHistory.length > 0 && curPageIndex > 0) {
            slideToPageInner(pageHistory[curPageIndex-1],'right',callback,'false');
        } else {
            $.bae_toast("已经到第一页，不能再后退");
        }
    };
    var forward = function(callback) {
        if (curPageIndex < pageHistory.length-1) {
            slideToPageInner(pageHistory[curPageIndex+1],'left',callback,'false');
        } else {
            $.bae_toast("已经到最后一页，不能再前进");
        }
    };

    /**
     * 对用户可见的滑屏
     *
     * @param pageTo
     * @param direction
     * @param callback
     */
    var slideToPage = function(pageTo, direction, callback){
        console.log("slideToPage");
        var $pageTo = $("#"+pageTo);
        if($pageTo.length != 0){
            $pageTo.addClass("page")
        }
        slideToPageInner(pageTo, direction, callback,'true');
    };

    return {
        slideToPage: slideToPage,
        back:back,
        setStartPage:setStartPage
    }
};
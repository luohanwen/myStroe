;
$(function () {
    // This function calls getAttribute, which should be safe for data-* attributes
    $.extend({getAttrFixed:function (e, key) {
        var value = e.getAttribute(key);
        return value === "true" ? true : value === "false" ? false : value === null ? undefined : value
    }});

    $.fn.bae_button = function (options) {
        var $jqObj = this;
	    // Enforce options to be of type string
        options = (options && ($.type(options) === "object")) ? options : {};

        $.each($jqObj, function (index, ele) {
            var $a = $(ele);
            var a = ele;
	        //update style by params
            if ($a.attr("data-init")) {
                if (typeof options.inline == "boolean") {
                    $a.bae_button_setInline(options.inline)
                }
                if (typeof options.disable == "boolean") {
                    $a.bae_button_setDisable(options.disable)
                }
                if (typeof options.width == "string" || typeof options.width == "number") {
                    $a.bae_button_setWidth($.fn.bae_button_parsePixelValue(options.width))
                }
                if (typeof options.height == "string" || typeof options.height == "number") {
                    $a.bae_button_setHeight($.fn.bae_button_parsePixelValue(options.height))
                }
                return true
            }
	        //create bae_button style
            var o = $.extend({}, $.fn.bae_button.defaults, {
	    	    inline:options.inline !== undefined ? options.inline : $.getAttrFixed(a, "data-inline"),
		        shadow:true,
		        corners:true,
		        width:options.width !== undefined ? options.width : -1,
		        height:options.height !== undefined ? options.height : -1,
		        useDefaultStyle:options.useDefaultStyle !== undefined ? options.useDefaultStyle : true
	        }, options);
 
            if (o.useDefaultStyle) {
                var buttonClass = o.inline ? "ui-bae-btn-inline ui-bae-btn-up " : "ui-bae-btn ui-bae-btn-up ";
                buttonClass += o.shadow ? "ui-bae-shadow " : "";
                buttonClass += o.corners ? "ui-bae-btn-corner-all " : "";
                $a.addClass(buttonClass);
                $a.html('<span class="ui-bae-btn-inner" aria-hidden="true"><span class="ui-btn-text">' + $a.html() + '</span></span>')
            }
	        //flag for accomplishment of init.
            $a.attr("data-init", true);
            if (o.width != -1) {
                $a.css("width", o.width)
            }
            if (o.height != -1) {
                $a.css({height:o.height, lineHeight:o.height + "px"})
            }
            a.addEventListener("touchstart", function (ev) {
                $a.addClass("active")
            }, false);
            a.addEventListener("touchmove", function (ev) {
                ev.preventDefault()
            }, false);
            a.addEventListener("touchend", function (ev) {
                setTimeout(function () {
                    $a.removeClass("active")
                }, 300)
            }, false)
        });
        return $jqObj
    };

    $.fn.bae_button.defaults = {inline:false, width:-1, height:-1, useDefaultStyle:true};

    $.fn.bae_button_setDisable = function (state) {
	    //ui-bae-btn-disable
        state = (typeof(state) == "boolean");
        var $a = this;
        if (!$a.is("a")) {
            return
        }
        if (state) {
            if (!$a.hasClass("ui-bae-btn-disable")) {
                $a.addClass("ui-bae-btn-disable")
            }
        } else {
            if ($a.hasClass("ui-bae-btn-disable")) {
                $a.removeClass("ui-bae-btn-disable")
            }
        }
    };

    $.fn.bae_button_setInline = function (state) {
        state = (typeof(state) == "boolean");
        var $a = this;
        if (!$a.is("a")) {
            return
        }
        if (state) {
            if (!$a.hasClass("ui-bae-btn-inline")) {
                $a.addClass("ui-bae-btn-inline");
                $a.removeClass("ui-bae-btn")
            }
        } else {
            if (!$a.hasClass("ui-bae-btn")) {
                $a.addClass("ui-bae-btn");
                $a.removeClass("ui-bae-btn-inline")
            }
        }
    };
    $.fn.bae_button_setWidth = function (width) {
        if (typeof width == "number" && width > 0) {
            var $a = this;
            if ($a.is("a")) {
                $a.css("width", width)
            } else {
            }
        }
    };

    $.fn.bae_button_setHeight = function (height) {
        if (typeof height == "number" && height > 0) {
            var $a = this;
            if ($a.is("a")) {
                $a.css("height", height);
                $a.css("line-height", height + "px")
            } else {
            }
        }
    };

    $.fn.bae_button_parsePixelValue = function (p) {
        var val;
        if (String(p).indexOf("px") > -1) {
            val = parseInt(String(p).substring(0, p.length - 2));
            if (val > 0) {
                return val
            }
        } else {
            val = parseInt(String(p));
            if (typeof val == "number") {
                return val
            }
        }
        return 0
    }
});

$(function () {
    //将所有含有“data-role='bae_button'”属性的element，修改为bae_button样式的按钮
    $("[data-role='bae_button']").bae_button()
});
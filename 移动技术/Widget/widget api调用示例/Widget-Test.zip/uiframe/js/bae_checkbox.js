;
$(function () {
    $.fn.bae_checkbox = function (options) {
        var $jqObj = this;
        options = (options && ($.type(options) === "object")) ? options : {};
        $.each($jqObj, function (index, ele) {
            var $checkbox = $(ele);
	        //update style by params
            if ($checkbox.attr("data-init")) {
                if (typeof options.disable == "boolean") {
                    $checkbox.bae_checkbox_setDisable(options.disable)
                }
                return true
            }
	        //create bae checkbox style
            if ($checkbox.attr("type") !== "checkbox") {
                return true
            }
            var o = $.extend({}, $.fn.bae_checkbox.defaults, {
	    	    disable:options.disable !== undefined ? options.disable : ("disabled" == $checkbox.attr("disabled") ? true : false)
	        }, options);

	        //flag for accomplishment of init.
            $checkbox.attr("data-init", true);
            var $label = $("<label></label>");
            $label.insertAfter($checkbox);
            var style = o.disable ? "ui-bae-checkbox ui-bae-checkbox-disable" : "ui-bae-checkbox ui-bae-checkbox-enable";
            o.disable ? $checkbox.attr("disabled", "disabled") : $checkbox.removeAttr("disabled");
            $checkbox.addClass(style);
            $label.addClass(style);
            $label.bind("click", function () {
                $checkbox.get(0).click()
            })
        })
    };

    $.fn.bae_checkbox.defaults = {disable:false};

    $.fn.bae_checkbox_setDisable = function (state) {
        typeof(state) == "boolean" ? state : state = false;
        var $checkbox = this;
        var $label = this.next();
        if ($checkbox.is('input')) {
            if (state) {
                if (!$checkbox.hasClass("ui-bae-checkbox-disable")) {
                    $checkbox.removeClass("ui-bae-checkbox-enable");
                    $checkbox.addClass("ui-bae-checkbox-disable");
                    $checkbox.attr("disabled", "disabled")
                }
            } else {
                if (!$checkbox.hasClass("ui-bae-checkbox-enable")) {
                    $checkbox.removeClass("ui-bae-checkbox-disable");
                    $checkbox.addClass("ui-bae-checkbox-enable");
                    $checkbox.removeAttr("disabled")
                }
            }
        }
        if ($label.is('label')) {
            if (state) {
                if (!$label.hasClass("ui-bae-checkbox-disable")) {
                    $label.removeClass("ui-bae-checkbox-enable");
                    $label.addClass("ui-bae-checkbox-disable")
                }
            } else {
                if (!$label.hasClass("ui-bae-checkbox-enable")) {
                    $label.removeClass("ui-bae-checkbox-disable");
                    $label.addClass("ui-bae-checkbox-enable")
                }
            }
        }
    }
});

$(function () {
    //将所有含有“data-role='bae_checkbox'”属性的element，修改为bae_checkbox样式的按钮
    $("[data-role='bae_checkbox']").bae_checkbox()
});
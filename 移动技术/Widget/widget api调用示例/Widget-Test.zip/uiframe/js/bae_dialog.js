;$(function () {
    $.bae_dialog = function (options) {
    	// default options
        var defaults = {
		id:"bae_dialog_box", //默认的id
		title:"确认提示", //默认确认提示
		message:"", //默认弹出提示内容为空
		position:"center", //显示的位置默认水平和垂直居中，另外还有左上"left-top"、左下"left-bottom"、右上"right-top"、右下"right-bottom"四个位置
		width:-1, 
		height:-1, 
		type:"confirm", //对话框类型[confirm:有确认及取消按钮/alert:仅有确认按钮]
		modal:true, //是否使用蒙版
		useAnimation:false, 
		autoClose:undefined, //自动关闭延时，如果用户设定了该值
		okEvent:undefined, //点击确认按钮事件，如果用户设定了该值，否则默认只是关闭窗口
		cancelEvent:undefined //点击取消按钮事件，如果用户设定了该值，否则默认只是关闭窗口
	};

    //use "plugin" to reference the current instance of the object
    var plugin = this;
    plugin.timer = undefined;

    // this will hold the merged default, and user-provided options
    plugin.settings = $.extend({}, defaults, options);

    //get the width and height of element (exclude hidden element)
    var getSize = function (ele) {
        var width = ele.offsetWidth, height = ele.offsetHeight;
        if (!width && !height) {
            var style = ele.style;
            var cssShow = "position:absolute;visibility:hidden;display:block;left:-9999px;top:-9999px;";
            var cssBack = "position:" + style.position + ";visibility:" + style.visibility + ";display:" + style.display + ";left:" + style.left + ";top:" + style.top;
            ele.style.cssText = cssShow;
            width = ele.offsetWidth;
            height = ele.offsetHeight;
            ele.style.cssText = cssBack
        }
        return{"width":parseInt(width), "height":parseInt(height)}
    };

    // 遍历
    var each = function (a, b) {
        for (var i = 0, len = a.length; i < len; i++)b(a[i], i)
    };

    // 事件绑定
    var bind = function (obj, type, fn) {
        if (!obj)return;
        if (obj.attachEvent) {
            obj['e' + type + fn] = fn;
            obj[type + fn] = function () {
                obj['e' + type + fn](window.event)
            };
            obj.attachEvent('on' + type, obj[type + fn])
        } else {
            obj.addEventListener(type, fn, false)
        }
    };

    // 移除事件
    var unbind = function (obj, type, fn) {
        if (!obj)return;
        if (obj.detachEvent) {
            try {
                obj.detachEvent('on' + type, obj[type + fn]);
                obj[type + fn] = null
            } catch (e) {
            }
        } else {
            obj.removeEventListener(type, fn, false)
        }
    };

    // 阻止浏览器默认行为
    var stopDefault = function (e) {
        e.preventDefault ? e.preventDefault() : e.returnValue = false
    };

    // 获取页面滚动条位置
    var getScrollPos = function () {
        var dd = document.documentElement, db = document.body;
        return{left:Math.max(dd.scrollLeft, db.scrollLeft), top:Math.max(dd.scrollTop, db.scrollTop)}
    };

    /**
     * 计算位置
     * @param ele
     */
    var computePosition = function (ele) {
        var zoom = $("body").css("zoom");
        if (!zoom) {
            zoom = 1
        }

        //根据IE的渲染模式 获取高度
        var c_height = document.compatMode != "BackCompat" ? document.documentElement.clientHeight : document.body.clientHeight;
        var pos = getSize(ele);
        var pos_w = pos.width * zoom, pos_h = pos.height * zoom;
        var l = 0, t = 0;
        switch (plugin.settings.position) {
            case'left-top':
                l = 2;
                t = 2;
                break;
            case'left-bottom':
                l = 2;
                t = c_height - pos_h - 2;
                break;
            case'right-top':
                l = document.body.clientWidth - pos_w - 2;
                t = 2;
                break;
            case'right-bottom':
                l = document.body.clientWidth - pos_w - 2;
                t = c_height - pos_h - 2;
                break;
            case'center-bottom':
                l = (document.body.clientWidth - pos_w) / 2;
                t = c_height - pos_h - 2;
                break;
            default:
                l = (document.body.clientWidth - pos_w) / 2;
                t = (c_height - pos_h) / 2
        }
        ele.style.left = l / zoom + 'px';
        ele.style.top = t / zoom + 'px'
    };

    /**
     * 初始化函数
     */
    plugin.init = function () {
        plugin.dialog = document.getElementById(plugin.settings.id);
        plugin.cover = document.getElementById('bae_dialog_mask');
        if (plugin.settings.modal && !plugin.cover) {//公用一个cover层，这样避免冗余标签
            plugin.cover = document.createElement('div');
            plugin.cover.className = "ui-bae-screen-mask";
            plugin.cover.id = 'bae_dialog_mask';
            plugin.cover.style.display = 'none';
            document.body.appendChild(plugin.cover);
            //禁止触摸屏幕移动蒙版后的网页
            plugin.cover.addEventListener('touchmove', function (e) {
                e.preventDefault()
            }, false)
        }
        if (!plugin.dialog) {
            plugin.dialog = document.createElement('div');//对话框
            plugin.dialog.className = 'ui-bae-dialog-box ui-bae-btn-corner-all ui-bae-shadow';
            plugin.dialog.id = plugin.settings.id;
            document.body.appendChild(plugin.dialog)
        }
        if (plugin.settings.width > 0) {
            plugin.dialog.style.width = plugin.settings.width
        }
        if (plugin.settings.height > 0) {
            plugin.dialog.style.height = plugin.settings.height
        }
        //重新构建一个弹出层
        if (!plugin.dialogBody) {
            plugin.dialogBody = document.createElement('div');
            plugin.dialog.appendChild(plugin.dialogBody)
        } else {
            while (plugin.dialogBody.lastChild) {
                plugin.dialogBody.removeChild(plugin.dialogBody.lastChild)
            }
        }
        plugin.dialogBody.innerHTML = "<div class='title ui-forbid-user-select'>" + plugin.settings.title + "</div><div class='message'>" + plugin.settings.message + '</div>';
        var buttons = document.createElement('div');
        buttons.className = "buttons";
        if (plugin.settings.type == 'confirm') {
            buttons.innerHTML = "<a data-inline='true'>确定</a>&nbsp;<a data-inline='true'>取消</a>"
        } else {
            buttons.innerHTML = "<a data-inline='true'>确定</a>"
        }
        plugin.dialogBody.appendChild(buttons);
        //OK button
        var btns = buttons.getElementsByTagName('a');
        if (plugin.settings.type == 'confirm') {
            $(btns).bae_button({width:150, height:27})
        } else {
            btns[0].style.width = "90%";
            $(btns[0]).bae_button()
        }
        bind(btns[0], 'click', function () {
            plugin.close();
            if (plugin.settings.okEvent) {
                setTimeout(function () {
                    plugin.settings.okEvent()
                }, 10)
            }
        });

        //Cancel button
        bind(btns[1], 'click', function () {
            plugin.close();
            if (plugin.settings.cancelEvent) {
                setTimeout(function () {
                    plugin.settings.cancelEvent()
                }, 10)
            }
        });

        //计算位置
        computePosition(plugin.dialog);

        //处理自动关闭
        if (plugin.settings.autoClose) {
            var delay = 5000;
            try {
                delay = parseInt(plugin.settings.autoClose)
            } catch (e) {
            }
            plugin.timer = setTimeout(function () {
                plugin.close()
            }, delay)
        }
    };

    /**
     * 页面鼠标操作限制
     * @param evt
     */
    plugin.mouse = function (evt) {
        stopDefault(evt || window.event);
        var p = getScrollPos(), left = p.left, top = p.top;
        scroll(left, top)
    };

    /**
     * open the dialog
     */
    plugin.open = function () {
        each(['DOMMouseScroll', 'mousewheel', 'scroll', 'contextmenu'], function (o, i) {
            bind(document, o, plugin.mouse)
        });
        if (plugin.settings.useAnimation) {
            $(plugin.dialog).fadeIn();
            if (plugin.settings.modal) {
                $(plugin.cover).fadeIn()
            } else {
                plugin.cover.style.display = 'none'
            }
        } else {
            plugin.dialog.style.display = 'block';
            if (plugin.settings.modal) {
                plugin.cover.style.display = 'block'
            } else {
                plugin.cover.style.display = 'none'
            }
        }
    };

    /**
     * close the dialog
     */
    plugin.close = function () {
        plugin.settings.autoClose = undefined;
        if (undefined != plugin.timer) {
            clearTimeout(plugin.timer);
            plugin.timer = undefined
        }
        each(['DOMMouseScroll', 'mousewheel', 'scroll', 'contextmenu'], function (o, i) {
            unbind(document, o, plugin.mouse)
        });
        if (plugin.settings.useAnimation) {
            $(plugin.dialog).fadeOut();
            $(plugin.cover).fadeOut()
        } else {
            plugin.dialog.style.display = 'none';
            plugin.cover.style.display = 'none'
        }
    };

	//add event listener of resize
    $(window).resize(function () {
        computePosition(plugin.dialog)
    });
    plugin.init();
    plugin.open();
    return{
        close:function () {
            plugin.close()
        },
        destory:function () {
            document.body.removeChild(plugin.dialog);
            if (plugin.cover) {
                document.body.removeChild(plugin.cover)
            }
            delete plugin
        }
    }}
});
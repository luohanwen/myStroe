/**
 * Created with JetBrains WebStorm.
 * User: Administrator
 * Date: 13-8-30
 * Time: 上午10:53
 * To change this template use File | Settings | File Templates.
 */
$(function () {
    $.fn.bae_search = function (options) {
        var baeSearch = this;
        options=(options&&typeof (options)==="object")?options:{};
        $.each(baeSearch,function(index,element){
            var jqEle = $(element);
            if(jqEle.attr("data-init"))//初始化过的搜索框的处理
            {
                if (typeof options.placeholder==="string") {
                    $(element.children[0]).bae_search_setPlaceholder(options.placeholder);
                }
                if (typeof options.icon==="string") {
                    $(element.children[0]).bae_search_setIcon(options.icon);
                }
                if(typeof options.text==="string"){
                    $(element.children[1]).bae_search_setText(options.text);
                }
                return;
            }
            var txt=jqEle.text().trim(); //获得的文本框默认的输入内容*/
            var dataText= jqEle.attr("data-text");//按钮上的文字
            var imgUrl=jqEle.attr("data-icon");//图片路径
            var _options= $.extend({},{"placeholder":txt==""? $.fn.bae_search.defaults.placeholder:txt,"icon":(imgUrl!=""&&imgUrl!=undefined)?imgUrl: $.fn.bae_search.defaults.icon,"text":(dataText==""||dataText==undefined)? $.fn.bae_search.defaults.text:dataText},options) ;
            jqEle.addClass("ui-bae-search");
            var textChangeFuncName=jqEle.attr("data-change");
            var divEle=$('<div class="ui-bae-search-left"><input type="search"> </div>');
            if(textChangeFuncName!=""&&textChangeFuncName!=undefined)
            {
                divEle=$('<div class="ui-bae-search-left"><input type="search" oninput=eval('+textChangeFuncName+')(this.value)></div>');
            }
            divEle.get(0).children[0].placeholder=_options.placeholder;
            divEle.css({'background-image':'url("'+_options.icon+'")'});
            jqEle.empty();
            jqEle.append(divEle);
            //为input绑定change事件
            $(divEle.get(0).children[0]).bind("change",function(){
                if(textChangeFuncName!=""&&textChangeFuncName!=undefined)
                {
                    try{
                        eval(textChangeFuncName+"('"+this.value.trim()+"')");
                    }
                    catch (e){console.log(e.message)}
                }
            });
            var aEle=$('<a href="#"><span>'+_options.text+'</span></a>');
            aEle.click(function(){
                var btnClickFuncName=jqEle.attr("data-event");
				if(')'==btnClickFuncName.charAt(btnClickFuncName.length-1) || ';'==btnClickFuncName.charAt(btnClickFuncName.length-1)){
                    try {
						eval(btnClickFuncName);
					}
					catch (e) {
					}
                }
				else {
					try {
						eval(btnClickFuncName+"('"+this.previousSibling.firstChild.value.trim()+"')");
					}
					catch (e) {
					}
				}
            });
            var aE=aEle.get(0);
            aE.addEventListener("touchstart", function (ev) {
                aEle.addClass("active");
            }, false);
            aE.addEventListener("touchmove", function (ev) {
                ev.preventDefault()
            }, false);
            aE.addEventListener("touchend", function (ev) {
                setTimeout(function () {
                    aEle.removeClass("active");
                }, 300)
            }, false);
            jqEle.append(aEle);
            jqEle.attr("data-init",true);
        });
    }
    $.fn.bae_search.defaults={"icon":"uiframe/images/bae_search_icon.png","text":"确定","placeholder":"请输入关键字"}; //默认的搜索属性
    $.fn.bae_search_setPlaceholder=function(data){
        var Ele=this;
        Ele.get(0).children[0].placeholder=data;
    }
    $.fn.bae_search_setIcon=function(data){
        var Ele=$(this);
        Ele.css({'background-image':'url("'+data+'")'});
    }
    $.fn.bae_search_setText=function(data){
        var Ele=$(this);
        Ele.empty();
        Ele.append($('<span>'+data+'</span>'));
    }
});
$(function () {
    $("[data-role='bae_search']").bae_search();
});

﻿$.fn.bae_tabs = function (options) {
    var $jqObj = this;
    options=(options&&(typeof options==="object")?options:{});
    $.each($jqObj, function (index, element) {
        var selectedTabs = $(element);
        if(selectedTabs.attr("data-init"))//判断是此tab标签是否初始化过
        {
            if(typeof options.selected==="number"||typeof options.selected==="string")
            {
                selectedTabs.bae_tabs_setSelected(parseInt(String(options.selected)));//改变指定标签的选中状态
            }
            return;
        }
        selectedTabs.addClass("ui-bae-tabs");
        var tabs = selectedTabs.find("[data-role='bae_tab']");
        var tabButtons = $('<div class="ui-bae-tab-buttons"></div>');
        var tabWidth = 100.0 / tabs.length;
        var selectedButton;
        $.each(tabs, function (index, element) {
            var tabContent = $(element);
            tabContent.addClass("unselected");
            var tabButtonName = tabContent.attr("data-tab-name");
            var tabButton = $('<a href="javascript:;" style="width:' + tabWidth + '%"><span style="overflow:hidden;height:40px;">' + tabButtonName + '</span></a>');
            tabButton.click(function () {
                $(this).addClass("current").siblings().removeClass("current");
                var tabIndex = $(this).index();
                var tempTabs = selectedTabs.find("[data-role='bae_tab']");
                $(tempTabs[tabIndex]).addClass("selected").removeClass("unselected").siblings(".selected").removeClass("selected").addClass("unselected");
                var tabChangeFuncName = tabContent.attr("data-event");
                if(')'==tabChangeFuncName.charAt(tabChangeFuncName.length-1) || ';'==tabChangeFuncName.charAt(tabChangeFuncName.length-1)){
                    try {
						eval(tabChangeFuncName);
					}
					catch (e) {
					}
                }
				else {
					try {
						eval(tabChangeFuncName + "(" + tabIndex + ")");
					}
					catch (e) {
					}
				}
            });
            tabButtons.append(tabButton);
            if (tabContent.attr("data-tab-selected") === "true") {
                selectedButton = tabButton;
                tabContent.removeClass("unselected");
                tabContent.addClass("selected")
            }
        });
        var contents = $(selectedTabs.html());
        selectedTabs.empty();
        selectedTabs.append($(tabButtons));
        selectedTabs.append(contents);
        if (typeof(selectedButton) == "object")selectedButton.addClass("current").siblings().removeClass("current")
        selectedTabs.attr("data-init",true)
    })
};
$.fn.bae_tabs_setSelected=function(tabIndex){
    var Ele=this;
    var aEle=Ele.get(0).children[0].children;//获得对应的a标签
    if(tabIndex>=aEle.length) //参数的值大于等于标签的个数，不执行操作
    {
        return;
    }
    var tabs=Ele.find("[data-role='bae_tab']");// 获得所有的tabs
    $(aEle[tabIndex]).addClass("current").siblings().removeClass("current");
    $(tabs[tabIndex]).addClass("selected").removeClass("unselected").siblings(".selected").removeClass("selected").addClass("unselected");
}
$(function () {
    //将所有含有“data-role='bae_tabs'”属性的element，修改为bae_tabs样式的按钮
    $("[data-role='bae_tabs']").bae_tabs()
});
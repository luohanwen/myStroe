;
$(function() {
    $.bae_progressbar = function(options) {
        return new $.bae_progressbar_inner(options)
    };
    $.bae_progressbar_inner = function(options) {
        var plugin = this;
        var defaults = {icon: "",message: "",position: "center",modal: true,useAnimation: false,canCancel: false,beforeShow: undefined,afterClose: undefined};
        plugin.settings = $.extend({}, defaults, options);
        var getSize = function(elem) {
            var width = elem.offsetWidth, height = elem.offsetHeight;
            if (!width && !height) {
                var style = elem.style;
                var cssShow = "position:absolute;visibility:hidden;display:block;left:-9999px;top:-9999px;";
                var cssBack = "position:" + style.position + ";visibility:" + style.visibility + ";display:" + style.display + ";left:" + style.left + ";top:" + style.top;
                elem.style.cssText = cssShow;
                width = elem.offsetWidth;
                height = elem.offsetHeight;
                elem.style.cssText = cssBack
            }
            return {"width": parseInt(width),"height": parseInt(height)}
        };
        var nodeEle = document.getElementById("bae_progress_box");
        plugin.init = function() {
            if (!nodeEle) {
                nodeEle = document.createElement("div");
                nodeEle.setAttribute("id", "bae_progress_box");
                document.body.appendChild(nodeEle);
            }

            if (plugin.settings.modal) {
                nodeEle.setAttribute("class", "ui-bae-screen-mask ui-forbid-user-select")
            } else {
                nodeEle.setAttribute("class", "ui-forbid-user-select")
            }
            nodeEle.style.clear = "both";
            var content = " <div class='ui-bae-progress ui-bae-btn-corner-all'> ";
            if (plugin.settings.icon == '') {
                content += "  <div class='inline-block'><div class='loading_icon'><div class='ui-bae-block-g' id='ui-bae-rotate-01'></div><div class='ui-bae-block-g' id='ui-bae-rotate-02'></div><div class='ui-bae-block-g' id='ui-bae-rotate-03'></div><div class='ui-bae-block-g' id='ui-bae-rotate-04'></div><div class='ui-bae-block-g' id='ui-bae-rotate-05'></div><div class='ui-bae-block-g' id='ui-bae-rotate-06'></div><div class='ui-bae-block-g' id='ui-bae-rotate-07'></div><div class='ui-bae-block-g' id='ui-bae-rotate-08'></div></div><div name='msg' class='inline-block'></div></div>"
            } else {
                content += "  <div class='inline-block'><img class='loading_icon' alt='' src='" + plugin.settings.icon + "'></div> <div name='msg' class='inline-block'></div></div>"
            }
            nodeEle.innerHTML = content;
            nodeEle.style.display = "block";

            nodeEle.addEventListener('touchmove', function(e) {
                e.preventDefault()
            }, false);
//            loadingDialog = $("#bae_progress_box");
//            loadingDialog.find("[name='msg']").html();
            $(nodeEle).find("[name='msg']").html(plugin.settings.message);
            var winBody = nodeEle.children[0];
            if (plugin.settings.canCancel == false) {
                nodeEle.removeEventListener('touchstart', plugin.close, false);
                nodeEle.removeEventListener('click', plugin.close, false)
            } else {
                nodeEle.addEventListener('touchstart', plugin.close, false);
                nodeEle.addEventListener('click', plugin.close, false)
            }
            computePosition(winBody);
            nodeEle.style.display = "block";
        };
        plugin.close = function() {
            try {
                nodeEle.style.display="none";
//                document.body.removeChild(loadingDialog[0])
            } catch (e) {
            }
            if (plugin.settings.afterClose) {
                plugin.settings.afterClose()
            }
        };
        var computePosition = function(ele) {
            if (!ele)
                return;
            var zoom = $("body").css("zoom");
            if (!zoom) {
                zoom = 1
            }
            var c_height = document.compatMode != "BackCompat" ? document.documentElement.clientHeight : document.body.clientHeight;
            var pos = getSize(ele);
            var pos_w = pos.width * zoom, pos_h = pos.height * zoom;
            var l = 0, t = 0;
            switch (plugin.settings.position) {
                case 'center-bottom':
                    l = (document.body.clientWidth - pos_w) / 2;
                    t = c_height - pos_h - 2;
                    break;
                default:
                    l = (document.body.clientWidth - pos_w) / 2;
                    t = (c_height - pos_h) / 2
            }
            ele.style.left = l / zoom + 'px';
            ele.style.top = t / zoom + 'px'
        };
        $(window).resize(function() {
            computePosition(nodeEle.children[0])
        });
        if (plugin.settings.beforeShow) {
            plugin.settings.beforeShow()
        }
        plugin.init();
        return {close: function() {
            plugin.close()
        }}
    }
});
